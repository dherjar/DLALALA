import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { BankAccount, insertBankAccountSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

type BankAccountFormData = {
  bankName: string;
  cardNumber: string;
  pin: string;
};

export default function EWalletPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isAddingAccount, setIsAddingAccount] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");

  const { data: accounts, isLoading } = useQuery<BankAccount[]>({
    queryKey: ["/api/bank-accounts"],
    // Only show accounts belonging to the current user
    select: (accounts) => accounts.filter(account => account.userId === user?.id)
  });

  const form = useForm<BankAccountFormData>({
    resolver: zodResolver(insertBankAccountSchema.pick({
      bankName: true,
      cardNumber: true,
      pin: true
    })),
    defaultValues: {
      bankName: "",
      cardNumber: "",
      pin: "",
    },
  });

  const addAccountMutation = useMutation({
    mutationFn: async (data: BankAccountFormData) => {
      const res = await apiRequest("POST", "/api/bank-accounts", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to add bank account");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-accounts"] });
      setIsAddingAccount(false);
      form.reset();
      toast({
        title: "Success",
        description: "Bank account added successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add bank account",
        variant: "destructive",
      });
    }
  });

  const withdrawMutation = useMutation({
    mutationFn: async ({ accountId, amount }: { accountId: number; amount: number }) => {
      const res = await apiRequest("POST", `/api/bank-accounts/${accountId}/withdraw`, { amount });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to process withdrawal");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-accounts"] });
      setWithdrawAmount("");
      toast({
        title: "Success",
        description: "Withdrawal processed successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process withdrawal",
        variant: "destructive",
      });
    }
  });

  const directPaymentMutation = useMutation({
    mutationFn: async ({ accountId, amount }: { accountId: number; amount: number }) => {
      const res = await apiRequest("POST", "/api/direct-payment", { accountId, amount });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to process payment");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-accounts"] });
      setPaymentAmount("");
      toast({
        title: "Success",
        description: "Payment sent to admin successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process payment",
        variant: "destructive",
      });
    }
  });

  const handleWithdraw = (accountId: number) => {
    const amount = parseInt(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }
    withdrawMutation.mutate({ accountId, amount });
  };

  const handleDirectPayment = (accountId: number) => {
    const amount = parseInt(paymentAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }
    directPaymentMutation.mutate({ accountId, amount });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">E-Wallet</h1>
        <Dialog open={isAddingAccount} onOpenChange={setIsAddingAccount}>
          <DialogTrigger asChild>
            <Button>Add Bank Account</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Bank Account</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit((data) => addAccountMutation.mutate(data))}
                className="space-y-4"
              >
                <FormField
                  control={form.control}
                  name="bankName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bank Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="cardNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Card Number</FormLabel>
                      <FormControl>
                        <Input {...field} maxLength={16} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pin"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>PIN</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} maxLength={4} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full"
                  disabled={addAccountMutation.isPending}
                >
                  {addAccountMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    "Add Account"
                  )}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accounts?.map((account) => (
          <Card key={account.id}>
            <CardHeader>
              <CardTitle>{account.bankName}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Card Number:</span>
                  <span>****{account.cardNumber.slice(-4)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Balance:</span>
                  <span>{account.balance} Ores</span>
                </div>
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">Withdraw</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Withdraw Ores</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <Input
                          type="number"
                          placeholder="Amount to withdraw"
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                        />
                        <Button
                          className="w-full"
                          onClick={() => handleWithdraw(account.id)}
                          disabled={withdrawMutation.isPending}
                        >
                          {withdrawMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            "Withdraw"
                          )}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">Pay to Admin</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Direct Payment to Admin</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <Input
                          type="number"
                          placeholder="Amount to pay"
                          value={paymentAmount}
                          onChange={(e) => setPaymentAmount(e.target.value)}
                        />
                        <Button
                          className="w-full"
                          onClick={() => handleDirectPayment(account.id)}
                          disabled={directPaymentMutation.isPending}
                        >
                          {directPaymentMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            "Pay"
                          )}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}