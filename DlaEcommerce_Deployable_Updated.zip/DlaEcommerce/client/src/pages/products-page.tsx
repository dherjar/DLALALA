import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import ProductCard from "@/components/products/product-card";
import { useState, useEffect } from "react";
import { ShoppingCart } from "lucide-react";
import { useLocation } from "wouter";
import type { CartItem } from "@/types/cart";

export default function ProductsPage() {
  const [category, setCategory] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [cartItemsCount, setCartItemsCount] = useState(0);
  const [, setLocation] = useLocation();

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  useEffect(() => {
    const updateCartCount = () => {
      const cart: CartItem[] = JSON.parse(localStorage.getItem("cart") || "[]");
      setCartItemsCount(cart.reduce((sum, item) => sum + item.quantity, 0));
    };

    // Update initial count
    updateCartCount();

    // Listen for storage changes
    window.addEventListener("storage", updateCartCount);
    // Custom event for cart updates
    window.addEventListener("cartUpdated", updateCartCount);

    return () => {
      window.removeEventListener("storage", updateCartCount);
      window.removeEventListener("cartUpdated", updateCartCount);
    };
  }, []);

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="h-[400px] rounded-lg bg-muted animate-pulse"
          />
        ))}
      </div>
    );
  }

  const filteredProducts = products?.filter((product) => {
    const matchesCategory = category === "all" || product.category === category;
    const matchesSearch = product.name.toLowerCase().includes(search.toLowerCase()) ||
                         product.brand.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const categories = ["all", ...Array.from(new Set(products?.map(p => p.category) || []))];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4">
        <Input
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-xs"
        />
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts?.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {/* Floating Cart Button */}
      <Button
        className="fixed bottom-6 right-6 rounded-full h-16 w-16 shadow-lg"
        onClick={() => setLocation("/cart")}
      >
        <div className="relative">
          <ShoppingCart className="h-6 w-6" />
          {cartItemsCount > 0 && (
            <div className="absolute -top-2 -right-2 bg-primary-foreground text-primary rounded-full h-5 w-5 flex items-center justify-center text-xs">
              {cartItemsCount}
            </div>
          )}
        </div>
      </Button>
    </div>
  );
}