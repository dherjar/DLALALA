import { useQuery, useMutation } from "@tanstack/react-query";
import { BankAccount } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { Loader2, Plus, Minus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function AdminBalancePage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [editingBalance, setEditingBalance] = useState<{[key: number]: string}>({});

  const { data: accounts, isLoading } = useQuery<BankAccount[]>({
    queryKey: ["/api/bank-accounts"],
    enabled: user?.role === "admin"
  });

  const updateBalanceMutation = useMutation({
    mutationFn: async ({ accountId, balance, operation }: { accountId: number; balance: number; operation: 'update' | 'deduct' }) => {
      const finalBalance = operation === 'deduct' 
        ? (accounts?.find(a => a.id === accountId)?.balance || 0) - balance
        : balance;

      console.log('Sending balance update request:', { accountId, balance: finalBalance });

      const res = await apiRequest("PATCH", `/api/bank-accounts/${accountId}/balance`, { balance: finalBalance });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || 'Failed to update balance');
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-accounts"] });
      setEditingBalance({});
      toast({
        title: "Success",
        description: "Balance updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update balance",
        variant: "destructive",
      });
    }
  });

  if (!user || user.role !== "admin") {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-destructive">Access Denied</h2>
        <p className="text-muted-foreground mt-2">You must be an admin to view this page.</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const handleUpdateBalance = (accountId: number, operation: 'update' | 'deduct') => {
    const newBalance = parseInt(editingBalance[accountId]);
    if (isNaN(newBalance) || newBalance < 0) {
      toast({
        title: "Error",
        description: "Please enter a valid balance",
        variant: "destructive",
      });
      return;
    }

    if (operation === 'deduct') {
      const currentBalance = accounts?.find(a => a.id === accountId)?.balance || 0;
      if (newBalance > currentBalance) {
        toast({
          title: "Error",
          description: "Cannot deduct more than current balance",
          variant: "destructive",
        });
        return;
      }
    }

    updateBalanceMutation.mutate({ accountId, balance: newBalance, operation });
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Balance Management</h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accounts?.map((account) => (
          <Card key={account.id}>
            <CardHeader>
              <CardTitle>{account.bankName}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Card Number</p>
                  <p>****{account.cardNumber.slice(-4)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Current Balance</p>
                  <p>{account.balance} Ores</p>
                </div>
                <div className="flex flex-col gap-2">
                  <Input
                    type="number"
                    placeholder="Amount"
                    value={editingBalance[account.id] || ""}
                    onChange={(e) => setEditingBalance({
                      ...editingBalance,
                      [account.id]: e.target.value
                    })}
                  />
                  <div className="flex gap-2">
                    <Button
                      className="flex-1"
                      onClick={() => handleUpdateBalance(account.id, 'update')}
                      disabled={updateBalanceMutation.isPending}
                    >
                      {updateBalanceMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          <Plus className="w-4 h-4 mr-1" /> Update
                        </>
                      )}
                    </Button>
                    <Button
                      className="flex-1"
                      variant="destructive"
                      onClick={() => handleUpdateBalance(account.id, 'deduct')}
                      disabled={updateBalanceMutation.isPending}
                    >
                      {updateBalanceMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          <Minus className="w-4 h-4 mr-1" /> Deduct
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}