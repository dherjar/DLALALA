import { Redirect } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import ProductsPage from "./products-page";

export default function HomePage() {
  const { user } = useAuth();

  // Redirect admin to admin products page
  if (user?.role === "admin") {
    return <Redirect to="/admin/products" />;
  }

  // For customers, show the products page
  return <ProductsPage />;
}