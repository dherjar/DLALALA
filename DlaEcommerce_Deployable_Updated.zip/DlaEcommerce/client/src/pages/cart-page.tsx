import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import CartItem from "@/components/cart/cart-item";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { INR_TO_ORES_RATE } from "@shared/schema";
import { loadStripe } from "@stripe/stripe-js";
import type { CartItemType } from "@/types/cart";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export default function CartPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [paymentMethod, setPaymentMethod] = useState<"cod" | "ewallet" | "stripe">("cod");
  const [address, setAddress] = useState("");
  const [selectedAccountId, setSelectedAccountId] = useState<string>("");

  const { data: bankAccounts } = useQuery({
    queryKey: ["/api/bank-accounts"],
    enabled: paymentMethod === "ewallet"
  });

  const [cartItems, setCartItems] = useState<CartItemType[]>(() => {
    const saved = localStorage.getItem("cart");
    return saved ? JSON.parse(saved) : [];
  });

  const totalOres = Math.round(
    cartItems.reduce((sum, item) => sum + (item.priceInr * item.quantity * INR_TO_ORES_RATE), 0)
  );

  const checkoutMutation = useMutation({
    mutationFn: async () => {
      if (paymentMethod === "stripe") {
        const stripe = await stripePromise;
        if (!stripe) throw new Error("Stripe failed to initialize");

        const res = await apiRequest("POST", "/api/create-payment-intent", {
          items: cartItems,
          totalOres,
          shippingAddress: address,
        });
        const { clientSecret } = await res.json();

        const { error } = await stripe.confirmPayment({
          elements: null,
          confirmParams: {
            return_url: window.location.origin + "/orders",
          },
          clientSecret,
        });

        if (error) {
          throw new Error(error.message);
        }
      } else {
        const res = await apiRequest("POST", "/api/orders", {
          items: cartItems,
          totalOres,
          paymentMethod,
          shippingAddress: address,
          ...(paymentMethod === "ewallet" && { accountId: parseInt(selectedAccountId) }),
        });

        if (!res.ok) {
          const error = await res.json();
          throw new Error(error.error || "Failed to place order");
        }
        return res.json();
      }
    },
    onSuccess: () => {
      localStorage.removeItem("cart");
      toast({
        title: "Order placed successfully!",
        description: "You can track your order in the Orders page",
      });
      setLocation("/orders");
    },
    onError: (error: any) => {
      toast({
        title: "Order Failed",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const removeFromCart = (productId: number) => {
    const newItems = cartItems.filter(item => item.productId !== productId);
    setCartItems(newItems);
    localStorage.setItem("cart", JSON.stringify(newItems));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    const newItems = cartItems.map(item =>
      item.productId === productId ? { ...item, quantity } : item
    );
    setCartItems(newItems);
    localStorage.setItem("cart", JSON.stringify(newItems));
  };

  const handleCheckout = async () => {
    if (paymentMethod === "ewallet") {
      if (!selectedAccountId) {
        toast({
          title: "Error",
          description: "Please select a bank account for payment",
          variant: "destructive",
        });
        return;
      }

      const selectedAccount = bankAccounts?.find(acc => acc.id.toString() === selectedAccountId);
      if (!selectedAccount || selectedAccount.balance < totalOres) {
        toast({
          title: "Insufficient Balance",
          description: "Please add more Ores to your selected account or choose another payment method",
          variant: "destructive",
        });
        return;
      }
    }
    checkoutMutation.mutate();
  };

  if (cartItems.length === 0) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Your cart is empty</h2>
        <Button onClick={() => setLocation("/")}>Continue Shopping</Button>
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div className="space-y-4">
        <h2 className="text-2xl font-bold mb-6">Shopping Cart</h2>
        {cartItems.map((item) => (
          <CartItem
            key={item.productId}
            item={item}
            onRemove={removeFromCart}
            onUpdateQuantity={updateQuantity}
          />
        ))}
      </div>

      <div className="space-y-6">
        <div className="rounded-lg border p-6">
          <h3 className="text-lg font-semibold mb-4">Order Summary</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Total Items:</span>
              <span>{cartItems.reduce((sum, item) => sum + item.quantity, 0)}</span>
            </div>
            <div className="flex justify-between font-bold">
              <span>Total Amount:</span>
              <span>{totalOres} Ores</span>
            </div>
          </div>
        </div>

        <div className="rounded-lg border p-6 space-y-4">
          <h3 className="text-lg font-semibold">Payment Method</h3>
          <RadioGroup value={paymentMethod} onValueChange={(v: "cod" | "ewallet" | "stripe") => {
            setPaymentMethod(v);
            setSelectedAccountId("");
          }}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="cod" id="cod" />
              <Label htmlFor="cod">Cash on Delivery</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="ewallet" id="ewallet" />
              <Label htmlFor="ewallet">E-Wallet</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="stripe" id="stripe" />
              <Label htmlFor="stripe">Pay with Card (Stripe)</Label>
            </div>
          </RadioGroup>

          {paymentMethod === "ewallet" && bankAccounts && bankAccounts.length > 0 && (
            <div className="space-y-2">
              <Label>Select Bank Account</Label>
              <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select an account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id.toString()}>
                      {account.bankName} (Balance: {account.balance} Ores)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        <div className="rounded-lg border p-6 space-y-4">
          <h3 className="text-lg font-semibold">Shipping Address</h3>
          <Input
            placeholder="Enter your delivery address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
        </div>

        <Button
          className="w-full"
          size="lg"
          onClick={handleCheckout}
          disabled={
            checkoutMutation.isPending ||
            !address ||
            (paymentMethod === "ewallet" && !selectedAccountId)
          }
        >
          Place Order
        </Button>
      </div>
    </div>
  );
}