import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Wallet, Package, Settings, Box } from "lucide-react";

export default function Navbar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  if (!user) return null;

  const isAdmin = user.role === "admin";
  const navItems = isAdmin
    ? [
        { href: "/admin/products", label: "Products", icon: Box },
        { href: "/admin/orders", label: "Orders", icon: Package },
        { href: "/admin/balance", label: "Balance", icon: Settings },
        { href: "/ewallet", label: "E-Wallet", icon: Wallet },
      ]
    : [
        { href: "/", label: "Products", icon: ShoppingCart },
        { href: "/cart", label: "Cart", icon: ShoppingCart },
        { href: "/ewallet", label: "E-Wallet", icon: Wallet },
        { href: "/orders", label: "Orders", icon: Package },
      ];

  return (
    <nav className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4">
        <div className="h-16 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href={isAdmin ? "/admin/products" : "/"}>
              <a className="text-xl font-bold">DLA Store</a>
            </Link>
            <div className="flex items-center space-x-2">
              {navItems.map(({ href, label, icon: Icon }) => (
                <Link key={href} href={href}>
                  <a
                    className={`flex items-center space-x-1 px-3 py-2 rounded-md transition-colors ${
                      location === href
                        ? "bg-primary-foreground/10"
                        : "hover:bg-primary-foreground/5"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{label}</span>
                  </a>
                </Link>
              ))}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span>{user.username}</span>
            <Button
              variant="outline"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              Logout
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}