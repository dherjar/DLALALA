import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Minus, Plus, Trash2 } from "lucide-react";
import { INR_TO_ORES_RATE } from "@shared/schema";
import type { CartItem } from "@/types/cart";

interface CartItemProps {
  item: CartItem;
  onRemove: (productId: number) => void;
  onUpdateQuantity: (productId: number, quantity: number) => void;
}

export default function CartItem({ item, onRemove, onUpdateQuantity }: CartItemProps) {
  const priceInOres = Math.round(item.priceInr * INR_TO_ORES_RATE);
  const totalOres = priceInOres * item.quantity;

  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-4">
        <div className="w-24 h-24 flex-shrink-0">
          <img
            src={item.imageUrl}
            alt={item.name}
            className="w-full h-full object-cover rounded-md"
          />
        </div>

        <div className="flex-grow">
          <h3 className="font-medium">{item.name}</h3>
          <p className="text-sm text-muted-foreground">{item.brand}</p>
          <p className="text-sm mt-1">
            <span className="font-medium">{priceInOres} Ores</span>
            <span className="text-muted-foreground ml-2">
              (₹{item.priceInr})
            </span>
          </p>
        </div>

        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => onUpdateQuantity(item.productId, item.quantity - 1)}
              disabled={item.quantity <= 1}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <Input
              type="number"
              value={item.quantity}
              onChange={(e) => {
                const value = parseInt(e.target.value);
                if (!isNaN(value) && value > 0) {
                  onUpdateQuantity(item.productId, value);
                }
              }}
              className="w-16 text-center"
              min="1"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={() => onUpdateQuantity(item.productId, item.quantity + 1)}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex items-center gap-4">
            <p className="font-medium">{totalOres} Ores</p>
            <Button
              variant="destructive"
              size="icon"
              onClick={() => onRemove(item.productId)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}