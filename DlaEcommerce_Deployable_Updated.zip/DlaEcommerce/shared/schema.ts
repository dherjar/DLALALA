import { sqliteTable, text, integer, blob } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import type { InferModel } from 'drizzle-orm';

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("customer"),
});

export const products = sqliteTable("products", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  priceInr: integer("price_inr").notNull(),
  imageUrl: text("image_url").notNull(),
  stock: integer("stock").notNull().default(0),
  discount: integer("discount").notNull().default(0),
});

export const bankAccounts = sqliteTable("bank_accounts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  bankName: text("bank_name").notNull(),
  cardNumber: text("card_number").notNull(),
  pin: text("pin").notNull(),
  balance: integer("balance").notNull().default(0),
});

export const orders = sqliteTable("orders", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  items: blob("items", { mode: "json" }).notNull(),
  totalOres: integer("total_ores").notNull(),
  status: text("status").notNull().default("pending"),
  paymentMethod: text("payment_method").notNull(),
  shippingAddress: text("shipping_address").notNull(),
  createdAt: integer("created_at").notNull().default(sql`(strftime('%s', 'now'))`),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export const insertBankAccountSchema = createInsertSchema(bankAccounts).pick({
  bankName: true,
  cardNumber: true,
  pin: true,
}).extend({
  bankName: z.string().min(2, "Bank name must be at least 2 characters"),
  cardNumber: z.string().length(16, "Card number must be 16 digits"),
  pin: z.string().length(4, "PIN must be 4 digits"),
});
export const insertOrderSchema = createInsertSchema(orders);

export type User = InferModel<typeof users>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Product = InferModel<typeof products>;
export type BankAccount = InferModel<typeof bankAccounts>;
export type Order = InferModel<typeof orders>;

// Constants
export const INR_TO_ORES_RATE = 0.01; // 1 Ore = 100 INR
