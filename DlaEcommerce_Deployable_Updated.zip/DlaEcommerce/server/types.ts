import { User, InsertUser, Product, BankAccount, Order } from "@shared/schema";
import session from "express-session";

export interface IStorage {
  sessionStore: session.Store;

  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Product operations
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: Omit<Product, "id">): Promise<Product>;
  deleteProduct(id: number): Promise<boolean>;
  updateProductDiscount(id: number, discount: number): Promise<Product | undefined>;

  // Bank Account operations
  getBankAccounts(userId: number): Promise<BankAccount[]>;
  getAllBankAccounts(): Promise<BankAccount[]>;
  createBankAccount(account: Omit<BankAccount, "id">): Promise<BankAccount>;
  updateBankAccountBalance(id: number, balance: number): Promise<BankAccount | undefined>;

  // Order operations
  createOrder(order: Omit<Order, "id">): Promise<Order>;
  getOrders(userId?: number): Promise<Order[]>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
}