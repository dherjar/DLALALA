import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertOrderSchema, insertBankAccountSchema } from "@shared/schema";
import Stripe from "stripe";
import { insertProductSchema } from "@shared/schema";

// If Stripe key is missing, we'll set up a mock that will log warnings but not crash the app
let stripe: Stripe | null = null;
let stripeEnabled = false;

if (process.env.STRIPE_SECRET_KEY) {
  try {
    stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2025-02-24.acacia" as const
    });
    stripeEnabled = true;
    console.log("Stripe payment processing enabled");
  } catch (error) {
    console.error("Failed to initialize Stripe:", error);
  }
} else {
  console.warn("STRIPE_SECRET_KEY not provided. Stripe payment processing will be disabled.");
}

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Products
  app.get("/api/products", async (_req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  // Add new product endpoint (Admin only)
  app.post("/api/products", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(401).json({ error: "Only admin can add products" });
    }

    try {
      const productData = insertProductSchema.parse(req.body);
      
      // Ensure required fields have default values if not provided
      const productToCreate = {
        ...productData,
        discount: productData.discount ?? 0,
        stock: productData.stock ?? 0
      };
      
      const newProduct = await storage.createProduct(productToCreate);
      res.status(201).json(newProduct);
    } catch (error) {
      console.error("Product creation error:", error);
      res.status(400).json({ error: "Invalid product data" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(401).json({ error: "Only admin can delete products" });
    }

    try {
      const productId = parseInt(req.params.id);
      const success = await storage.deleteProduct(productId);

      if (!success) {
        return res.status(404).json({ error: "Product not found" });
      }

      res.status(200).json({ message: "Product deleted successfully" });
    } catch (error) {
      console.error("Product deletion error:", error);
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  // Add endpoint to update product discount
  app.patch("/api/products/:id/discount", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(401).json({ error: "Only admin can update product discounts" });
    }

    try {
      const productId = parseInt(req.params.id);
      const discount = parseInt(req.body.discount);

      if (isNaN(discount) || discount < 0 || discount > 100) {
        return res.status(400).json({ error: "Invalid discount percentage" });
      }

      const updatedProduct = await storage.updateProductDiscount(productId, discount);

      if (!updatedProduct) {
        return res.status(404).json({ error: "Product not found" });
      }

      res.json(updatedProduct);
    } catch (error) {
      console.error("Product discount update error:", error);
      res.status(500).json({ error: "Failed to update product discount" });
    }
  });


  // Bank Accounts
  app.get("/api/bank-accounts", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    // If admin, get all accounts, otherwise get user's accounts
    const accounts = req.user.role === "admin"
      ? await storage.getAllBankAccounts()
      : await storage.getBankAccounts(req.user.id);
    res.json(accounts);
  });

  app.post("/api/bank-accounts", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const parsedData = insertBankAccountSchema.parse({
        bankName: req.body.bankName,
        cardNumber: req.body.cardNumber,
        pin: req.body.pin
      });

      const account = await storage.createBankAccount({
        ...parsedData,
        userId: req.user.id,
        balance: 0
      });

      res.status(201).json(account);
    } catch (error) {
      res.status(400).json({ error: "Invalid bank account data" });
    }
  });

  // Stripe Payment Intent
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    // Check if Stripe is enabled
    if (!stripeEnabled || !stripe) {
      return res.status(503).json({
        error: "Stripe payment processing is not available. Please add a STRIPE_SECRET_KEY to your environment variables."
      });
    }

    try {
      const { totalOres, items, shippingAddress } = req.body;

      // Create a PaymentIntent with the order amount and currency
      const paymentIntent = await stripe!.paymentIntents.create({
        amount: Math.round(totalOres * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId: req.user.id,
          items: JSON.stringify(items),
          shippingAddress
        }
      });

      res.json({
        clientSecret: paymentIntent.client_secret
      });
    } catch (error: any) {
      res.status(400).json({
        error: error.message
      });
    }
  });

  // Orders
  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const orders = req.user.role === "admin"
      ? await storage.getOrders()
      : await storage.getOrders(req.user.id);
    res.json(orders);
  });

  app.post("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { paymentMethod, totalOres, accountId, items, shippingAddress } = req.body;

      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: "Invalid items in cart" });
      }

      if (!shippingAddress) {
        return res.status(400).json({ error: "Shipping address is required" });
      }

      if (paymentMethod === "ewallet") {
        if (!accountId) {
          return res.status(400).json({ error: "Bank account must be selected for e-wallet payment" });
        }

        const account = await storage.getBankAccount(accountId);
        if (!account) {
          return res.status(404).json({ error: "Selected bank account not found" });
        }

        if (account.userId !== req.user.id) {
          return res.status(403).json({ error: "Not authorized to use this account" });
        }

        if (account.balance < totalOres) {
          return res.status(400).json({ error: "Insufficient balance" });
        }

        // Deduct from selected account
        await storage.updateBankAccountBalance(
          account.id,
          account.balance - totalOres
        );

        // Find admin's account to credit the payment
        const admin = await storage.getUserByUsername("dheerajadmin");
        if (admin) {
          const adminAccounts = await storage.getBankAccounts(admin.id);
          const adminAccount = adminAccounts[0];
          if (adminAccount) {
            await storage.updateBankAccountBalance(
              adminAccount.id,
              adminAccount.balance + totalOres
            );
          }
        }
      }

      const order = await storage.createOrder({
        userId: req.user.id,
        items,
        totalOres,
        paymentMethod,
        shippingAddress,
        status: "pending",
        createdAt: Math.floor(Date.now() / 1000)
      });

      res.status(201).json(order);
    } catch (error) {
      console.error("Order creation error:", error);
      res.status(400).json({ error: "Failed to create order" });
    }
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(401);
    }
    const order = await storage.updateOrderStatus(
      parseInt(req.params.id),
      req.body.status,
    );
    if (!order) return res.sendStatus(404);
    res.json(order);
  });

  // Admin - Balance Management
  app.patch("/api/bank-accounts/:id/balance", async (req, res) => {
    console.log('Balance update request:', {
      isAuthenticated: req.isAuthenticated(),
      userRole: req?.user?.role,
      accountId: req.params.id,
      requestBody: req.body
    });

    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    if (req.user.role !== "admin") {
      return res.status(403).json({ error: "Not authorized" });
    }

    try {
      const accountId = parseInt(req.params.id);
      const balance = parseInt(req.body.balance);

      if (isNaN(balance) || balance < 0) {
        return res.status(400).json({ error: "Invalid balance amount" });
      }

      console.log('Getting account:', accountId);
      const account = await storage.getBankAccount(accountId);
      if (!account) {
        return res.status(404).json({ error: "Account not found" });
      }

      console.log('Updating balance:', { accountId, newBalance: balance });
      const updatedAccount = await storage.updateBankAccountBalance(
        accountId,
        balance
      );

      if (!updatedAccount) {
        return res.status(500).json({ error: "Failed to update balance" });
      }

      console.log('Balance updated successfully:', updatedAccount);
      res.json(updatedAccount);
    } catch (error) {
      console.error("Balance update error:", error);
      res.status(500).json({ error: "Failed to update balance" });
    }
  });

  // Order cancellation endpoint
  app.post("/api/orders/:id/cancel", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const orderId = parseInt(req.params.id);
      const order = await storage.getOrder(orderId);

      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }

      if (order.userId !== req.user.id) {
        return res.status(403).json({ error: "Not authorized to cancel this order" });
      }

      if (order.status !== "pending") {
        return res.status(400).json({ error: "Only pending orders can be cancelled" });
      }

      // If payment was made through e-wallet, refund the amount
      if (order.paymentMethod === "ewallet") {
        // Find admin's bank account
        const admin = await storage.getUserByUsername("dheerajadmin");
        if (!admin) {
          return res.status(500).json({ error: "Admin account not found" });
        }

        const adminAccounts = await storage.getBankAccounts(admin.id);
        const adminAccount = adminAccounts[0];
        if (!adminAccount) {
          return res.status(500).json({ error: "Admin bank account not found" });
        }

        // First verify admin has sufficient balance for the refund
        if (adminAccount.balance < order.totalOres) {
          return res.status(400).json({ error: "Insufficient admin balance for refund" });
        }

        // Deduct from admin's account first
        await storage.updateBankAccountBalance(
          adminAccount.id,
          adminAccount.balance - order.totalOres
        );

        // Then refund to user's account
        const userAccounts = await storage.getBankAccounts(req.user.id);
        if (userAccounts.length > 0) {
          const userAccount = userAccounts[0];
          await storage.updateBankAccountBalance(
            userAccount.id,
            userAccount.balance + order.totalOres
          );
        }
      }

      const updatedOrder = await storage.updateOrderStatus(orderId, "cancelled");
      res.json(updatedOrder);
    } catch (error) {
      console.error("Failed to cancel order:", error);
      res.status(500).json({ error: "Failed to cancel order" });
    }
  });

  // Add withdrawal endpoint
  app.post("/api/bank-accounts/:id/withdraw", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const accountId = parseInt(req.params.id);
      const amount = parseInt(req.body.amount);

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({ error: "Invalid withdrawal amount" });
      }

      const account = await storage.getBankAccount(accountId);
      if (!account) {
        return res.status(404).json({ error: "Account not found" });
      }

      if (account.userId !== req.user.id) {
        return res.status(403).json({ error: "Not authorized to access this account" });
      }

      if (account.balance < amount) {
        return res.status(400).json({ error: "Insufficient balance" });
      }

      const updatedAccount = await storage.updateBankAccountBalance(
        accountId,
        account.balance - amount
      );

      res.json(updatedAccount);
    } catch (error) {
      res.status(500).json({ error: "Failed to process withdrawal" });
    }
  });

  // Update direct payment route
  app.post("/api/direct-payment", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { accountId, amount } = req.body;
      const parsedAmount = parseInt(amount);

      if (isNaN(parsedAmount) || parsedAmount <= 0) {
        return res.status(400).json({ error: "Invalid payment amount" });
      }

      const account = await storage.getBankAccount(accountId);
      if (!account) {
        return res.status(404).json({ error: "Account not found" });
      }

      if (account.userId !== req.user.id) {
        return res.status(403).json({ error: "Not authorized to use this account" });
      }

      if (account.balance < parsedAmount) {
        return res.status(400).json({ error: "Insufficient balance" });
      }

      // Find admin's bank account
      const admin = await storage.getUserByUsername("dheerajadmin");
      if (!admin) {
        return res.status(500).json({ error: "Admin account not found" });
      }

      const adminAccounts = await storage.getBankAccounts(admin.id);
      const adminAccount = adminAccounts[0];
      if (!adminAccount) {
        return res.status(500).json({ error: "Admin bank account not found" });
      }

      // Deduct from user's account
      await storage.updateBankAccountBalance(
        accountId,
        account.balance - parsedAmount
      );

      // Add to admin's account
      await storage.updateBankAccountBalance(
        adminAccount.id,
        adminAccount.balance + parsedAmount
      );

      res.json({ message: "Payment successful" });
    } catch (error) {
      res.status(500).json({ error: "Failed to process payment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}